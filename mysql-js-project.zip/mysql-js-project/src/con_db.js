module.exports = {
    host: 'localhost',
    user: 'root',
    password: 'mysql', 
    database: 'hmail_db',  
    waitForConnections: true,
    connectionLimit: 10,   // Número máximo de conexiones
    queueLimit: 0
};